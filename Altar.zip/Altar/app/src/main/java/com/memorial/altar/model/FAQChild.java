package com.memorial.altar.model;

/**
 * Created by yoon on 2017. 8. 29..
 */

public class FAQChild {

    private String mAnswer;

    public String getAnswer() {
        return mAnswer;
    }

    public void setAnswer(String answer) {
        mAnswer = answer;
    }
}
