package com.memorial.altar.common;

/**
 * Created by yoon on 2017. 8. 29..
 */

public class Common {

    public static final int NAV_REQUEST_NOTIFICATIONS = 1001;
    public static final int NAV_REQUEST_SETTINGS = 1002;
    public static final int NAV_REQUEST_FAQ = 1003;
}
