package com.memorial.altar.model;

/**
 * Created by yoon on 2017. 9. 5..
 */

public class BillingStar {

    private int mCount;
    private int mExtraCount;
    private int mPrice;

    public int getCount() {
        return mCount;
    }

    public void setCount(int count) {
        mCount = count;
    }

    public int getExtraCount() {
        return mExtraCount;
    }

    public void setExtraCount(int extraCount) {
        mExtraCount = extraCount;
    }

    public int getPrice() {
        return mPrice;
    }

    public void setPrice(int price) {
        mPrice = price;
    }
}
